import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyCfkzUyvVecH49CtxLTkM560uCUyXdCRHw",
  authDomain: "engineer-platform-cfdc6.firebaseapp.com",
  projectId: "engineer-platform-cfdc6",
  storageBucket: "engineer-platform-cfdc6.firebasestorage.app",
  messagingSenderId: "179730797731",
  appId: "1:179730797731:web:6717ee6b5784e926449b16",
  measurementId: "G-QN7E0GKVCQ",
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
