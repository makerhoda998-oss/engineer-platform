import React, { useState, useEffect, useCallback, useRef } from "react";
import {
  Home, LogIn, UserPlus, ShieldCheck, Users, BookOpen, FileText, Video,
  Image as ImageIcon, GraduationCap, Award, BarChart3, Phone, MessageCircle,
  Plus, Trash2, CheckCircle2, XCircle, ArrowRight, Settings, LogOut, Loader2,
  ClipboardList, TrendingUp
} from "lucide-react";
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";
import { auth, db } from "./firebase";
import {
  createUserWithEmailAndPassword, signInWithEmailAndPassword, sendEmailVerification,
  onAuthStateChanged, signOut,
} from "firebase/auth";
import {
  collection, doc, getDoc, setDoc, getDocs, addDoc, updateDoc, query, orderBy,
} from "firebase/firestore";


/* ---------------------------------------------------------
   منصة "Engineer التعليمية" — نسخة حقيقية مبنية على Firebase
   الألوان: أسود مائل للرمادي + ذهبي/برتقالي
--------------------------------------------------------- */

const NAVY = "#18181c";
const NAVY_LIGHT = "#222227";
const NAVY_CARD = "#1e1e23";
const GOLD = "#f2a93c";
const GOLD_SOFT = "#ffd98a";
const CYAN = "#4dd4dd";
const SUPPORT_PHONE = "01016094070";

const SUBJECTS = [
  { id: "arabic", name: "اللغة العربية", icon: "📗", color: "#4dd4dd" },
  { id: "english", name: "اللغة الإنجليزية", icon: "📘", color: "#5b9dff" },
  { id: "chemistry", name: "الكيمياء", icon: "⚗️", color: "#c084fc" },
  { id: "physics", name: "الفيزياء", icon: "🧲", color: "#ff6b6b" },
  { id: "biology", name: "الأحياء", icon: "🧬", color: "#4ade80" },
  { id: "french", name: "اللغة الفرنسية", icon: "📙", color: "#f472b6" },
  { id: "religion", name: "التربية الدينية", icon: "🕌", color: "#2dd4bf" },
  { id: "national", name: "التربية الوطنية", icon: "🏛️", color: "#fb923c" },
  { id: "math", name: "الرياضيات", icon: "📐", color: "#f2a93c" },
];

const ADMIN_EMAIL = "makerhoda998@gmail.com";
const CLOUDINARY_CLOUD_NAME = "bm9z0tis";
const CLOUDINARY_UPLOAD_PRESET = "my_uploader";
const EMAILJS_SERVICE_ID = "service_jobbv8h";
const EMAILJS_TEMPLATE_ID = "template_hj6j6zo";
const EMAILJS_PUBLIC_KEY = "VjZhlg5E62ZP_hbnd";

function uid(prefix = "id") {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

async function fetchUsers() {
  try {
    const snap = await getDocs(collection(db, "users"));
    const obj = {};
    snap.forEach((d) => { obj[d.id] = { identifier: d.id, ...d.data() }; });
    return obj;
  } catch (e) {
    console.error("fetchUsers failed", e);
    return {};
  }
}

async function saveUser(phoneKey, userData) {
  try {
    await setDoc(doc(db, "users", phoneKey), userData, { merge: true });
  } catch (e) {
    console.error("saveUser failed", e);
  }
}

async function fetchList(collName) {
  try {
    const snap = await getDocs(collection(db, collName));
    const list = [];
    snap.forEach((d) => list.push({ id: d.id, ...d.data() }));
    list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    return list;
  } catch (e) {
    console.error(`fetchList(${collName}) failed`, e);
    return [];
  }
}

async function addToList(collName, data) {
  try {
    await addDoc(collection(db, collName), data);
  } catch (e) {
    console.error(`addToList(${collName}) failed`, e);
  }
}

/* ---------------- Shared UI bits ---------------- */

function Logo({ size = "text-2xl" }) {
  return (
    <div className={`flex items-center gap-2 ${size} font-extrabold`}>
      <span style={{ color: GOLD }}>⚙️</span>
      <span style={{ color: GOLD }}>Engineer</span>
      <span className="text-white/90 font-bold text-base md:text-lg">التعليمية</span>
    </div>
  );
}

function SiteFooter() {
  return (
    <div className="text-center py-6 text-white/30 text-xs" dir="rtl">
      تصميم وتطوير:{" "}
      <a
        href="https://mahmoudabdullah.vercel.app"
        target="_blank"
        rel="noreferrer"
        className="font-bold hover:underline"
        style={{ color: GOLD }}
      >
        Mahmoud Abdullah
      </a>
    </div>
  );
}

function BackgroundDecor() {
  const blobs = [
    { top: "-8%", left: "-6%", size: 260, color: GOLD, opacity: 0.18 },
    { top: "10%", left: "78%", size: 200, color: CYAN, opacity: 0.14 },
    { top: "62%", left: "-8%", size: 220, color: "#c084fc", opacity: 0.12 },
    { top: "78%", left: "70%", size: 240, color: GOLD, opacity: 0.1 },
  ];
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none" style={{ zIndex: 0 }}>
      {blobs.map((b, i) => (
        <div
          key={i}
          className="absolute rounded-full"
          style={{
            top: b.top,
            left: b.left,
            width: b.size,
            height: b.size,
            background: `radial-gradient(circle at 35% 30%, ${b.color}, transparent 70%)`,
            opacity: b.opacity,
            filter: "blur(10px)",
            boxShadow: `0 40px 80px -20px ${b.color}55, inset -20px -20px 60px rgba(0,0,0,0.35), inset 20px 20px 40px rgba(255,255,255,0.06)`,
          }}
        />
      ))}
    </div>
  );
}

function Card({ children, className = "" }) {
  return (
    <div
      className={`rounded-2xl border shadow-lg ${className}`}
      style={{ background: NAVY_CARD, borderColor: "rgba(245,166,35,0.25)" }}
    >
      {children}
    </div>
  );
}

function GoldButton({ children, onClick, className = "", type = "button", disabled }) {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={`px-5 py-2.5 rounded-xl font-bold transition disabled:opacity-50 disabled:cursor-not-allowed ${className}`}
      style={{ background: `linear-gradient(135deg, ${GOLD}, #ffcf6b)`, color: NAVY }}
    >
      {children}
    </button>
  );
}

function GhostButton({ children, onClick, className = "" }) {
  return (
    <button
      onClick={onClick}
      className={`px-5 py-2.5 rounded-xl font-bold border transition text-white/90 hover:bg-white/5 ${className}`}
      style={{ borderColor: "rgba(255,255,255,0.2)" }}
    >
      {children}
    </button>
  );
}

function Input({ label, ...props }) {
  return (
    <label className="block mb-4 text-right">
      <span className="block mb-1.5 text-sm text-white/70">{label}</span>
      <input
        {...props}
        className="w-full rounded-xl px-4 py-2.5 outline-none text-white placeholder-white/30 border focus:ring-2 transition"
        style={{ background: NAVY_LIGHT, borderColor: "rgba(255,255,255,0.12)" }}
        onFocus={(e) => (e.target.style.boxShadow = `0 0 0 2px ${GOLD}55`)}
        onBlur={(e) => (e.target.style.boxShadow = "none")}
      />
    </label>
  );
}

function RoleBadge({ role }) {
  const map = {
    admin: { text: "أدمن", color: "#ff6b6b" },
    supervisor: { text: "مشرف", color: CYAN },
    student: { text: "طالب", color: "#8bd17c" },
  };
  const r = map[role] || map.student;
  return (
    <span
      className="text-xs px-2.5 py-1 rounded-full font-bold"
      style={{ background: `${r.color}22`, color: r.color, border: `1px solid ${r.color}55` }}
    >
      {r.text}
    </span>
  );
}

/* ---------------- Support Button (fixed) ---------------- */

function SupportButton() {
  return (
    <a
      href={`https://wa.me/2${SUPPORT_PHONE}`}
      target="_blank"
      rel="noreferrer"
      className="fixed bottom-5 left-5 z-50 flex items-center gap-2 px-4 py-3 rounded-full shadow-2xl font-bold text-sm"
      style={{ background: "#25D366", color: "#04270f" }}
      title={`دعم فني - ${SUPPORT_PHONE}`}
    >
      <MessageCircle size={18} />
      دعم فني
    </a>
  );
}

/* ---------------- Auth Screens ---------------- */

function AuthScreen({ onAuthed }) {
  const [mode, setMode] = useState("login"); // login | signup | otp
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [sentCode, setSentCode] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleLogin() {
    setError("");
    if (!email.trim() || !password) {
      setError("اكتب الإيميل وكلمة السر");
      return;
    }
    setBusy(true);
    try {
      const key = email.trim().toLowerCase();
      await signInWithEmailAndPassword(auth, key, password);
      const snap = await getDoc(doc(db, "users", key));
      setBusy(false);
      if (snap.exists()) {
        onAuthed({ identifier: key, ...snap.data() });
      } else {
        setError("الحساب مش مكتمل، جرب تعمل حساب جديد");
      }
    } catch (err) {
      console.error(err);
      setBusy(false);
      setError("الإيميل أو كلمة السر غلط");
    }
  }

  async function handleSendCode() {
    setError("");
    if (!name.trim() || !email.trim() || !password) {
      setError("من فضلك املأ كل الحقول");
      return;
    }
    if (password.length < 6) {
      setError("كلمة السر لازم تكون 6 حروف/أرقام على الأقل");
      return;
    }
    if (!window.emailjs) {
      setError("خدمة الإرسال لسه مش جاهزة، حدّث الصفحة وجرب تاني");
      return;
    }
    setBusy(true);
    try {
      const code = String(Math.floor(1000 + Math.random() * 9000));
      await window.emailjs.send(
        EMAILJS_SERVICE_ID,
        EMAILJS_TEMPLATE_ID,
        { code, to_email: email.trim(), to_name: name.trim() },
        { publicKey: EMAILJS_PUBLIC_KEY }
      );
      setSentCode(code);
      setBusy(false);
      setMode("otp");
    } catch (err) {
      console.error(err);
      setBusy(false);
      setError("حصل خطأ في إرسال الكود، تأكد من الإيميل وحاول تاني");
    }
  }

  async function handleVerifyAndSignup() {
    setError("");
    if (otp.trim() !== sentCode) {
      setError("الكود غلط");
      return;
    }
    setBusy(true);
    try {
      const key = email.trim().toLowerCase();
      const cred = await createUserWithEmailAndPassword(auth, key, password);
      sendEmailVerification(cred.user).catch(() => {});
      const userData = {
        name: name.trim(),
        role: key === ADMIN_EMAIL.toLowerCase() ? "admin" : "student",
        createdAt: Date.now(),
      };
      await saveUser(key, userData);
      setBusy(false);
      onAuthed({ identifier: key, ...userData });
    } catch (err) {
      console.error(err);
      setBusy(false);
      if (err.code === "auth/email-already-in-use") {
        setError("في حساب موجود بالفعل بنفس الإيميل، جرب تسجيل الدخول");
      } else {
        setError("حصل خطأ، تأكد من الإيميل وحاول تاني");
      }
    }
  }

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4 relative"
      style={{ background: NAVY }}
      dir="rtl"
    >
      <BackgroundDecor />
      <div className="w-full max-w-md relative" style={{ zIndex: 1 }}>
        <div className="flex justify-center mb-6">
          <Logo size="text-3xl" />
        </div>
        <Card className="p-6 md:p-8">
          {mode !== "otp" ? (
            <>
              <div className="flex mb-6 rounded-xl overflow-hidden border" style={{ borderColor: "rgba(255,255,255,0.12)" }}>
                <button
                  onClick={() => { setMode("login"); setError(""); }}
                  className="flex-1 py-2.5 font-bold text-sm"
                  style={mode === "login" ? { background: GOLD, color: NAVY } : { color: "white" }}
                >
                  تسجيل الدخول
                </button>
                <button
                  onClick={() => { setMode("signup"); setError(""); }}
                  className="flex-1 py-2.5 font-bold text-sm"
                  style={mode === "signup" ? { background: GOLD, color: NAVY } : { color: "white" }}
                >
                  حساب جديد
                </button>
              </div>

              <div>
                {mode === "signup" && (
                  <Input label="الاسم بالكامل" value={name} onChange={(e) => setName(e.target.value)} placeholder="اكتب اسمك" />
                )}
                <Input
                  label="البريد الإلكتروني"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="example@mail.com"
                />
                <Input
                  label="كلمة السر"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                />
                {error && <p className="text-red-400 text-sm mb-3 text-right">{error}</p>}
                <GoldButton
                  onClick={mode === "login" ? handleLogin : handleSendCode}
                  className="w-full flex items-center justify-center gap-2"
                  disabled={busy}
                >
                  {busy ? <Loader2 className="animate-spin" size={18} /> : mode === "login" ? <LogIn size={18} /> : <ShieldCheck size={18} />}
                  {mode === "login" ? "دخول" : "إرسال رمز التأكيد"}
                </GoldButton>
              </div>
            </>
          ) : (
            <div>
              <div className="flex items-center gap-2 mb-4 text-white/80">
                <ShieldCheck size={20} style={{ color: GOLD }} />
                <p className="text-sm">اتبعتلك رسالة فيها كود التأكيد على {email}</p>
              </div>
              <Input label="رمز التأكيد" value={otp} onChange={(e) => setOtp(e.target.value)} placeholder="0000" maxLength={4} />
              {error && <p className="text-red-400 text-sm mb-3 text-right">{error}</p>}
              <GoldButton onClick={handleVerifyAndSignup} className="w-full flex items-center justify-center gap-2" disabled={busy}>
                {busy ? <Loader2 className="animate-spin" size={18} /> : <CheckCircle2 size={18} />}
                تأكيد وإنشاء الحساب
              </GoldButton>
              <button type="button" onClick={() => setMode("signup")} className="text-white/50 text-sm mt-3 w-full text-center">
                رجوع
              </button>
            </div>
          )}
        </Card>
        <SiteFooter />
      </div>
    </div>
  );
}

/* ---------------- Top Navbar ---------------- */

function Navbar({ user, view, setView, onLogout }) {
  const tabs = [
    { id: "home", label: "الرئيسية", icon: Home },
    { id: "results", label: "نتائجي", icon: Award },
  ];
  if (user.role === "supervisor" || user.role === "admin") {
    tabs.push({ id: "supervisor", label: "لوحة المشرف", icon: ClipboardList });
  }
  if (user.role === "admin") {
    tabs.push({ id: "admin", label: "لوحة الأدمن", icon: Settings });
  }
  return (
    <div
      className="sticky top-0 z-40 border-b backdrop-blur"
      style={{ background: `${NAVY}ee`, borderColor: "rgba(255,255,255,0.08)" }}
      dir="rtl"
    >
      <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between flex-wrap gap-3">
        <Logo />
        <div className="flex items-center gap-1.5 flex-wrap">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setView(t.id)}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-bold transition"
              style={
                view === t.id
                  ? { background: `${GOLD}22`, color: GOLD, border: `1px solid ${GOLD}55` }
                  : { color: "rgba(255,255,255,0.7)" }
              }
            >
              <t.icon size={16} />
              {t.label}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block">
            <p className="text-white text-sm font-bold leading-tight">{user.name}</p>
            <RoleBadge role={user.role} />
          </div>
          <button onClick={onLogout} className="text-white/60 hover:text-white p-2" title="تسجيل خروج">
            <LogOut size={18} />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Home (Subjects grid) ---------------- */

function HomePage({ setView, setActiveSubject }) {
  return (
    <div className="max-w-5xl mx-auto p-4 md:p-6" dir="rtl">
      <Card
        className="p-7 mb-7 text-center relative overflow-hidden"
        style={{ background: `linear-gradient(135deg, ${NAVY_LIGHT}, ${NAVY_CARD})` }}
      >
        <div
          className="absolute -top-10 -left-10 w-40 h-40 rounded-full opacity-20"
          style={{ background: GOLD, filter: "blur(40px)" }}
        />
        <h1 className="text-2xl md:text-3xl font-extrabold text-white mb-2 relative">اختَر مادتك وابدأ المذاكرة</h1>
        <p className="text-white/50 relative">فيديوهات شرح، ملخصات، وامتحانات تفاعلية لكل مادة</p>
      </Card>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3.5">
        {SUBJECTS.map((s) => (
          <button
            key={s.id}
            onClick={() => { setActiveSubject(s.id); setView("subject"); }}
            className="p-5 rounded-2xl border text-center hover:-translate-y-1 transition-all duration-200"
            style={{ background: NAVY_CARD, borderColor: "rgba(255,255,255,0.08)" }}
            onMouseEnter={(e) => (e.currentTarget.style.borderColor = `${s.color}88`)}
            onMouseLeave={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.08)")}
          >
            <div
              className="w-14 h-14 mx-auto mb-3 rounded-xl flex items-center justify-center text-2xl"
              style={{ background: `${s.color}22` }}
            >
              {s.icon}
            </div>
            <div className="text-white font-bold text-sm">{s.name}</div>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Subject Page ---------------- */

const TYPE_META = {
  video: { icon: Video, label: "فيديو", color: "#ff6b6b" },
  pdf: { icon: FileText, label: "PDF", color: CYAN },
  image: { icon: ImageIcon, label: "صورة / ملخص", color: "#8bd17c" },
};

function SubjectPage({ subjectId, content, exams, results, user, setView, setActiveExam }) {
  const subject = SUBJECTS.find((s) => s.id === subjectId);
  const items = content.filter((c) => c.subject === subjectId);
  const subjectExams = exams.filter((e) => e.subject === subjectId);

  return (
    <div className="max-w-5xl mx-auto p-4 md:p-6" dir="rtl">
      <button onClick={() => setView("home")} className="flex items-center gap-1 text-white/60 mb-4 text-sm">
        <ArrowRight size={16} /> رجوع للمواد
      </button>
      <h1 className="text-2xl font-extrabold text-white mb-5 flex items-center gap-2">
        <span>{subject?.icon}</span> {subject?.name}
      </h1>

      <h2 className="text-white/80 font-bold mb-3">المحتوى التعليمي</h2>
      {items.length === 0 ? (
        <Card className="p-6 text-white/50 text-center mb-6">لسه مفيش محتوى مرفوع في المادة دي</Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-3 mb-6">
          {items.map((it) => {
            const meta = TYPE_META[it.type];
            const Icon = meta.icon;
            return (
              <a
                key={it.id}
                href={it.url || "#"}
                target="_blank"
                rel="noreferrer"
                className="p-4 rounded-xl border flex items-center gap-3 hover:bg-white/5 transition"
                style={{ background: NAVY_CARD, borderColor: "rgba(255,255,255,0.1)" }}
              >
                <div className="p-2.5 rounded-lg" style={{ background: `${meta.color}22`, color: meta.color }}>
                  <Icon size={20} />
                </div>
                <div className="flex-1 text-right">
                  <p className="text-white font-bold text-sm">{it.title}</p>
                  <p className="text-white/40 text-xs">{meta.label}</p>
                </div>
              </a>
            );
          })}
        </div>
      )}

      <h2 className="text-white/80 font-bold mb-3">الامتحانات</h2>
      {subjectExams.length === 0 ? (
        <Card className="p-6 text-white/50 text-center">لسه مفيش امتحانات في المادة دي</Card>
      ) : (
        <div className="grid md:grid-cols-2 gap-3">
          {subjectExams.map((ex) => {
            const myResult = results.find((r) => r.examId === ex.id && r.userId === user.id);
            return (
              <Card key={ex.id} className="p-4 flex items-center justify-between gap-3">
                <div className="text-right">
                  <p className="text-white font-bold">{ex.title}</p>
                  <p className="text-white/40 text-xs">{ex.questions.length} سؤال</p>
                  {myResult && (
                    <p className="text-xs mt-1" style={{ color: GOLD }}>
                      نتيجتك: {myResult.percent}%
                    </p>
                  )}
                </div>
                <GoldButton onClick={() => { setActiveExam(ex.id); setView("exam"); }}>
                  {myResult ? "إعادة المحاولة" : "ابدأ الامتحان"}
                </GoldButton>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ---------------- Exam Taking ---------------- */

function ExamPage({ exam, user, onFinish, setView }) {
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(null);

  if (!exam) return null;

  function submit() {
    let correctCount = 0;
    exam.questions.forEach((q) => {
      if (answers[q.id] === q.correct) correctCount++;
    });
    const percent = Math.round((correctCount / exam.questions.length) * 1000) / 10;
    const result = {
      id: uid("res"),
      examId: exam.id,
      examTitle: exam.title,
      subject: exam.subject,
      userId: user.id,
      userName: user.name,
      score: correctCount,
      total: exam.questions.length,
      percent,
      createdAt: Date.now(),
    };
    setSubmitted(result);
    onFinish(result);
  }

  if (submitted) {
    const data = [
      { name: "صح", value: submitted.score, color: "#8bd17c" },
      { name: "غلط", value: submitted.total - submitted.score, color: "#ff6b6b" },
    ];
    return (
      <div className="max-w-lg mx-auto p-6 text-center" dir="rtl">
        <Card className="p-8">
          <Award size={40} style={{ color: GOLD }} className="mx-auto mb-3" />
          <h2 className="text-white text-xl font-extrabold mb-4">نتيجتك في {exam.title}</h2>
          <div className="w-56 h-56 mx-auto relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={data} dataKey="value" innerRadius={70} outerRadius={95} startAngle={90} endAngle={-270}>
                  {data.map((d, i) => (
                    <Cell key={i} fill={d.color} stroke="none" />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-3xl font-extrabold" style={{ color: GOLD }}>
                {submitted.percent}%
              </span>
              <span className="text-white/50 text-xs">النتيجة</span>
            </div>
          </div>
          <p className="text-white/70 mt-4">
            إجابات صح: <b className="text-white">{submitted.score}</b> من {submitted.total}
          </p>
          <GoldButton className="mt-6 w-full" onClick={() => setView("subject")}>
            رجوع للمادة
          </GoldButton>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto p-4 md:p-6" dir="rtl">
      <h1 className="text-xl font-extrabold text-white mb-5">{exam.title}</h1>
      <div className="space-y-4">
        {exam.questions.map((q, idx) => (
          <Card key={q.id} className="p-4">
            <p className="text-white font-bold mb-3">
              {idx + 1}. {q.text}
            </p>
            <div className="space-y-2">
              {q.options.map((op, oi) => (
                <label
                  key={oi}
                  className="flex items-center gap-2 p-2.5 rounded-lg border cursor-pointer"
                  style={{
                    borderColor: answers[q.id] === oi ? GOLD : "rgba(255,255,255,0.1)",
                    background: answers[q.id] === oi ? `${GOLD}15` : "transparent",
                  }}
                >
                  <input
                    type="radio"
                    name={q.id}
                    checked={answers[q.id] === oi}
                    onChange={() => setAnswers({ ...answers, [q.id]: oi })}
                  />
                  <span className="text-white/90 text-sm">{op}</span>
                </label>
              ))}
            </div>
          </Card>
        ))}
      </div>
      <GoldButton className="w-full mt-6" onClick={submit}>
        تسليم الامتحان
      </GoldButton>
    </div>
  );
}

/* ---------------- My Results Page ---------------- */

function ResultsPage({ user, results }) {
  const mine = results.filter((r) => r.userId === user.id).sort((a, b) => b.createdAt - a.createdAt);
  const chartData = mine
    .slice()
    .reverse()
    .map((r, i) => ({ name: `${i + 1}`, percent: r.percent }));

  return (
    <div className="max-w-3xl mx-auto p-4 md:p-6" dir="rtl">
      <h1 className="text-xl font-extrabold text-white mb-5">نتائجي</h1>
      {mine.length === 0 ? (
        <Card className="p-8 text-center text-white/50">لسه مقدمتش أي امتحان</Card>
      ) : (
        <>
          <Card className="p-4 mb-5" style={{ height: 220 }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.08)" />
                <XAxis dataKey="name" stroke="rgba(255,255,255,0.4)" fontSize={12} />
                <YAxis stroke="rgba(255,255,255,0.4)" fontSize={12} domain={[0, 100]} />
                <Tooltip contentStyle={{ background: NAVY_LIGHT, border: "none", borderRadius: 8 }} />
                <Line type="monotone" dataKey="percent" stroke={GOLD} strokeWidth={3} dot={{ fill: GOLD }} />
              </LineChart>
            </ResponsiveContainer>
          </Card>
          <div className="space-y-3">
            {mine.map((r) => (
              <Card key={r.id} className="p-4 flex items-center justify-between">
                <div className="text-right">
                  <p className="text-white font-bold">{r.examTitle}</p>
                  <p className="text-white/40 text-xs">{new Date(r.createdAt).toLocaleDateString("ar-EG")}</p>
                </div>
                <span className="font-extrabold text-lg" style={{ color: r.percent >= 50 ? "#8bd17c" : "#ff6b6b" }}>
                  {r.percent}%
                </span>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

/* ---------------- Supervisor Dashboard ---------------- */

function SupervisorDashboard({ user, content, exams, results, refreshAll }) {
  const [tab, setTab] = useState("upload");

  return (
    <div className="max-w-4xl mx-auto p-4 md:p-6" dir="rtl">
      <h1 className="text-xl font-extrabold text-white mb-5 flex items-center gap-2">
        <ClipboardList size={22} style={{ color: GOLD }} /> لوحة المشرف
      </h1>
      <div className="flex gap-2 mb-6 flex-wrap">
        {[
          { id: "upload", label: "رفع محتوى" },
          { id: "exam", label: "إنشاء امتحان" },
          { id: "reports", label: "تقارير الطلاب" },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className="px-4 py-2 rounded-lg text-sm font-bold border"
            style={
              tab === t.id
                ? { background: `${GOLD}22`, borderColor: GOLD, color: GOLD }
                : { borderColor: "rgba(255,255,255,0.15)", color: "white" }
            }
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "upload" && <UploadContentForm user={user} onDone={refreshAll} />}
      {tab === "exam" && <CreateExamForm user={user} onDone={refreshAll} />}
      {tab === "reports" && <ReportsTable content={content} exams={exams} results={results} />}
    </div>
  );
}

function UploadContentForm({ user, onDone }) {
  const [subject, setSubject] = useState(SUBJECTS[0].id);
  const [type, setType] = useState("video");
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [msg, setMsg] = useState("");
  const [busy, setBusy] = useState(false);
  const [uploadedName, setUploadedName] = useState("");
  const [widgetReady, setWidgetReady] = useState(false);

  useEffect(() => {
    if (window.cloudinary) {
      setWidgetReady(true);
      return;
    }
    const interval = setInterval(() => {
      if (window.cloudinary) {
        setWidgetReady(true);
        clearInterval(interval);
      }
    }, 300);
    const timeout = setTimeout(() => clearInterval(interval), 15000);
    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, []);

  function openUploadWidget() {
    setMsg("");
    if (!window.cloudinary) {
      setMsg("أداة الرفع لسه مش محمّلة، حدّث الصفحة (Refresh) وجرب تاني");
      console.error("window.cloudinary is undefined — the Cloudinary widget script did not load");
      return;
    }
    try {
      const widget = window.cloudinary.createUploadWidget(
        {
          cloudName: CLOUDINARY_CLOUD_NAME,
          uploadPreset: CLOUDINARY_UPLOAD_PRESET,
          multiple: false,
          resourceType: "auto",
          maxFileSize: 20000000,
        },
        (error, result) => {
          if (error) {
            console.error("Cloudinary widget error:", error);
            setMsg("حصل خطأ في الرفع: " + (error.statusText || error.message || "غير معروف"));
            return;
          }
          if (result && result.event === "success") {
            setUrl(result.info.secure_url);
            setUploadedName(result.info.original_filename);
            setMsg("");
          }
        }
      );
      widget.open();
    } catch (err) {
      console.error("Failed to open Cloudinary widget:", err);
      setMsg("حصل خطأ في فتح نافذة الرفع، جرب تحدّث الصفحة");
    }
  }

  async function handleAdd() {
    if (!title.trim() || !url.trim()) {
      setMsg("اكتب العنوان، وارفع ملف أو حط رابط");
      return;
    }
    setBusy(true);
    try {
      await addToList("content", {
        subject,
        type,
        title: title.trim(),
        url: url.trim(),
        addedBy: user.name,
        createdAt: Date.now(),
      });
      setTitle("");
      setUrl("");
      setUploadedName("");
      setMsg("تم رفع المحتوى بنجاح ✅");
      onDone();
      setTimeout(() => setMsg(""), 2500);
    } catch (err) {
      console.error(err);
      setMsg("حصل خطأ في الرفع، حاول تاني");
    }
    setBusy(false);
  }

  return (
    <Card className="p-5 md:p-6">
      <div>
        <div className="grid md:grid-cols-2 gap-3">
          <label className="block mb-4 text-right">
            <span className="block mb-1.5 text-sm text-white/70">المادة</span>
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full rounded-xl px-4 py-2.5 text-white border"
              style={{ background: NAVY_LIGHT, borderColor: "rgba(255,255,255,0.12)" }}
            >
              {SUBJECTS.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </label>
          <label className="block mb-4 text-right">
            <span className="block mb-1.5 text-sm text-white/70">نوع المحتوى</span>
            <select
              value={type}
              onChange={(e) => setType(e.target.value)}
              className="w-full rounded-xl px-4 py-2.5 text-white border"
              style={{ background: NAVY_LIGHT, borderColor: "rgba(255,255,255,0.12)" }}
            >
              <option value="video">فيديو شرح</option>
              <option value="pdf">ملف PDF</option>
              <option value="image">صورة / ملخص</option>
            </select>
          </label>
        </div>
        <Input label="العنوان" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثال: مراجعة الوحدة الأولى" />

        <GhostButton onClick={openUploadWidget} className="w-full flex items-center justify-center gap-2 mb-4">
          {widgetReady ? <Plus size={16} /> : <Loader2 size={16} className="animate-spin" />}
          {widgetReady ? "ارفع صورة أو PDF من جهازك" : "جاري تجهيز أداة الرفع..."}
        </GhostButton>
        {uploadedName && (
          <p className="text-xs mb-3 text-right" style={{ color: GOLD }}>تم رفع: {uploadedName} ✅</p>
        )}

        <Input
          label="أو حط رابط (يوتيوب مثلاً للفيديوهات)"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://..."
        />
        {msg && <p className="text-sm mb-3 text-right" style={{ color: GOLD }}>{msg}</p>}
        <GoldButton onClick={handleAdd} className="w-full flex items-center justify-center gap-2" disabled={busy}>
          {busy ? <Loader2 className="animate-spin" size={18} /> : <Plus size={18} />} رفع المحتوى
        </GoldButton>
      </div>
    </Card>
  );
}

function CreateExamForm({ user, onDone }) {
  const [subject, setSubject] = useState(SUBJECTS[0].id);
  const [title, setTitle] = useState("");
  const [questions, setQuestions] = useState([{ id: uid("q"), text: "", options: ["", ""], correct: 0 }]);
  const [msg, setMsg] = useState("");

  function updateQ(qi, patch) {
    setQuestions((qs) => qs.map((q, i) => (i === qi ? { ...q, ...patch } : q)));
  }
  function updateOption(qi, oi, value) {
    setQuestions((qs) =>
      qs.map((q, i) => (i === qi ? { ...q, options: q.options.map((o, j) => (j === oi ? value : o)) } : q))
    );
  }
  function addOption(qi) {
    setQuestions((qs) => qs.map((q, i) => (i === qi ? { ...q, options: [...q.options, ""] } : q)));
  }
  function addQuestion() {
    setQuestions((qs) => [...qs, { id: uid("q"), text: "", options: ["", ""], correct: 0 }]);
  }
  function removeQuestion(qi) {
    setQuestions((qs) => qs.filter((_, i) => i !== qi));
  }

  function handleSave() {
    if (!title.trim() || questions.some((q) => !q.text.trim() || q.options.some((o) => !o.trim()))) {
      setMsg("كمّل كل الأسئلة والاختيارات الأول");
      return;
    }
    (async () => {
      await addToList("exams", {
        subject,
        title: title.trim(),
        questions,
        createdBy: user.name,
        createdAt: Date.now(),
      });
      setTitle("");
      setQuestions([{ id: uid("q"), text: "", options: ["", ""], correct: 0 }]);
      setMsg("تم إنشاء الامتحان بنجاح ✅");
      onDone();
      setTimeout(() => setMsg(""), 2500);
    })();
  }

  return (
    <Card className="p-5 md:p-6">
      <div>
        <div className="grid md:grid-cols-2 gap-3">
          <label className="block mb-4 text-right">
            <span className="block mb-1.5 text-sm text-white/70">المادة</span>
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full rounded-xl px-4 py-2.5 text-white border"
              style={{ background: NAVY_LIGHT, borderColor: "rgba(255,255,255,0.12)" }}
            >
              {SUBJECTS.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </label>
          <Input label="عنوان الامتحان" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="مثال: امتحان الوحدة الثانية" />
        </div>

        <div className="space-y-4 mt-2">
          {questions.map((q, qi) => (
            <div key={q.id} className="p-4 rounded-xl border" style={{ borderColor: "rgba(255,255,255,0.1)" }}>
              <div className="flex justify-between items-center mb-2">
                <span className="text-white/60 text-sm">سؤال {qi + 1}</span>
                {questions.length > 1 && (
                  <button type="button" onClick={() => removeQuestion(qi)} className="text-red-400">
                    <Trash2 size={16} />
                  </button>
                )}
              </div>
              <input
                value={q.text}
                onChange={(e) => updateQ(qi, { text: e.target.value })}
                placeholder="نص السؤال"
                className="w-full rounded-lg px-3 py-2 text-white text-sm border mb-2"
                style={{ background: NAVY_LIGHT, borderColor: "rgba(255,255,255,0.12)" }}
              />
              <div className="space-y-1.5">
                {q.options.map((op, oi) => (
                  <div key={oi} className="flex items-center gap-2">
                    <input
                      type="radio"
                      checked={q.correct === oi}
                      onChange={() => updateQ(qi, { correct: oi })}
                      title="الإجابة الصحيحة"
                    />
                    <input
                      value={op}
                      onChange={(e) => updateOption(qi, oi, e.target.value)}
                      placeholder={`اختيار ${oi + 1}`}
                      className="flex-1 rounded-lg px-3 py-1.5 text-white text-sm border"
                      style={{ background: NAVY_LIGHT, borderColor: "rgba(255,255,255,0.12)" }}
                    />
                  </div>
                ))}
              </div>
              <button type="button" onClick={() => addOption(qi)} className="text-xs mt-2" style={{ color: CYAN }}>
                + إضافة اختيار
              </button>
            </div>
          ))}
        </div>
        <GhostButton onClick={addQuestion} className="mt-3 w-full flex items-center justify-center gap-2">
          <Plus size={16} /> إضافة سؤال
        </GhostButton>
        {msg && <p className="text-sm my-3 text-right" style={{ color: GOLD }}>{msg}</p>}
        <GoldButton onClick={handleSave} className="w-full mt-3">
          حفظ الامتحان
        </GoldButton>
      </div>
    </Card>
  );
}

function ReportsTable({ exams, results }) {
  if (results.length === 0) {
    return <Card className="p-8 text-center text-white/50">لسه مفيش نتائج طلاب</Card>;
  }
  const sorted = [...results].sort((a, b) => b.createdAt - a.createdAt);
  const avg = Math.round((results.reduce((s, r) => s + r.percent, 0) / results.length) * 10) / 10;
  return (
    <div>
      <Card className="p-4 mb-4 flex items-center gap-3">
        <TrendingUp style={{ color: GOLD }} />
        <p className="text-white">
          متوسط أداء كل الطلاب: <b style={{ color: GOLD }}>{avg}%</b> عبر {results.length} محاولة
        </p>
      </Card>
      <div className="space-y-2">
        {sorted.map((r) => (
          <Card key={r.id} className="p-3.5 flex items-center justify-between">
            <div className="text-right">
              <p className="text-white font-bold text-sm">{r.userName}</p>
              <p className="text-white/40 text-xs">{r.examTitle}</p>
            </div>
            <span className="font-extrabold" style={{ color: r.percent >= 50 ? "#8bd17c" : "#ff6b6b" }}>
              {r.percent}%
            </span>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Admin Dashboard ---------------- */

function AdminDashboard({ users, refreshAll }) {
  async function setRole(identifier, role) {
    try {
      await updateDoc(doc(db, "users", identifier), { role });
      refreshAll();
    } catch (err) {
      console.error(err);
    }
  }

  const list = Object.values(users).sort((a, b) => b.createdAt - a.createdAt);

  return (
    <div className="max-w-3xl mx-auto p-4 md:p-6" dir="rtl">
      <h1 className="text-xl font-extrabold text-white mb-5 flex items-center gap-2">
        <Settings size={22} style={{ color: GOLD }} /> لوحة الأدمن — إدارة المستخدمين
      </h1>
      <div className="space-y-2">
        {list.map((u) => (
          <Card key={u.id} className="p-4 flex items-center justify-between flex-wrap gap-2">
            <div className="text-right">
              <p className="text-white font-bold">{u.name}</p>
              <p className="text-white/40 text-xs">{u.identifier}</p>
            </div>
            <div className="flex items-center gap-2">
              <RoleBadge role={u.role} />
              {u.role !== "admin" && (
                <>
                  {u.role !== "supervisor" ? (
                    <GhostButton onClick={() => setRole(u.identifier, "supervisor")} className="!px-3 !py-1.5 text-xs">
                      ترقية لمشرف
                    </GhostButton>
                  ) : (
                    <GhostButton onClick={() => setRole(u.identifier, "student")} className="!px-3 !py-1.5 text-xs">
                      تنزيل لطالب
                    </GhostButton>
                  )}
                </>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ---------------- Main App ---------------- */

export default function App() {
  const [user, setUser] = useState(null);
  const [view, setView] = useState("home");
  const [activeSubject, setActiveSubject] = useState(null);
  const [activeExamId, setActiveExamId] = useState(null);

  const [users, setUsers] = useState({});
  const [content, setContent] = useState([]);
  const [exams, setExams] = useState([]);
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);

  const refreshAll = useCallback(async () => {
    const [u, c, e, r] = await Promise.all([
      fetchUsers(),
      fetchList("content"),
      fetchList("exams"),
      fetchList("results"),
    ]);
    setUsers(u);
    setContent(c);
    setExams(e);
    setResults(r);
  }, []);

  useEffect(() => {
    refreshAll();
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser && fbUser.email) {
        try {
          const key = fbUser.email.toLowerCase();
          const snap = await getDoc(doc(db, "users", key));
          if (snap.exists()) {
            setUser({ identifier: key, ...snap.data() });
          }
        } catch (err) {
          console.error(err);
        }
      }
      setLoading(false);
    });
    return () => unsub();
  }, [refreshAll]);

  async function handleFinishExam(result) {
    await addToList("results", result);
    setResults((prev) => [result, ...prev]);
  }

  async function handleLogout() {
    try {
      await signOut(auth);
    } catch (err) {
      console.error(err);
    }
    setUser(null);
    setView("home");
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: NAVY }}>
        <Loader2 className="animate-spin text-white" size={28} />
      </div>
    );
  }

  if (!user) {
    return <AuthScreen onAuthed={(u) => { setUser(u); setView("home"); }} />;
  }

  const activeExam = exams.find((e) => e.id === activeExamId);

  return (
    <div className="min-h-screen relative" style={{ background: NAVY }}>
      <BackgroundDecor />
      <div className="relative" style={{ zIndex: 1 }}>
        <Navbar user={user} view={view} setView={setView} onLogout={handleLogout} />

        {view === "home" && <HomePage setView={setView} setActiveSubject={setActiveSubject} />}

        {view === "subject" && (
          <SubjectPage
            subjectId={activeSubject}
            content={content}
            exams={exams}
            results={results}
            user={user}
            setView={setView}
            setActiveExam={setActiveExamId}
          />
        )}

        {view === "exam" && activeExam && (
          <ExamPage exam={activeExam} user={user} onFinish={handleFinishExam} setView={setView} />
        )}

        {view === "results" && <ResultsPage user={user} results={results} />}

        {view === "supervisor" && (user.role === "supervisor" || user.role === "admin") && (
          <SupervisorDashboard user={user} content={content} exams={exams} results={results} refreshAll={refreshAll} />
        )}

        {view === "admin" && user.role === "admin" && <AdminDashboard users={users} refreshAll={refreshAll} />}

        <SiteFooter />
        <SupportButton />
      </div>
    </div>
  );
}
